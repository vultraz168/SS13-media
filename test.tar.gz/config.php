<?php

// Change this.
define('BASE_URL', 'http://vista.bananabox.biz/media');

// What file extensions do you want to look for?
// Files must be tagged and cannot have spaces in the name.
$validExtensions = array('mp3');

// Names of your playlists, without the .PHP at the end.
// See playlists/example.php for an example.
// Must correspond with your jukebox's playlists list.
$playlists = array(
	'bar',  // Bar-specific shit.
	'jazz',
	'rock',
	'emagged'
);
