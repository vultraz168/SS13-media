<?php

$playlist=array(
		'emagged/sanic.mp3'=>array()
		'emagged/nigra.mp3'=>array()
);
